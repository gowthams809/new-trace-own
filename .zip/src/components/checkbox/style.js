import Styled from 'styled-components';
import { Checkbox } from 'antd';

const CheckboxStyle = Styled(Checkbox)`

`;

export { CheckboxStyle };
